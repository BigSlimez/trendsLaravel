document.getElementById("formOrder").addEventListener("submit", event => {
    event.preventDefault();



    let naam = document.getElementById("naam").value;
    let email = document.getElementById("email").value;
    let ticket = document.querySelector('input[name=ticket]:checked').value;

    let bestelling = {
        naam,
        mail,
        ticket
    }


    document.getElementById("message").innerHTML = printOrder(bestelling);
    saveOrder(bestelling);
});


function printOrder(bestelling) {
    return `<div class="alert alert-success" role="alert"> The order for customer
  $ {
      bestelling.name
  }
  with ermail $ {
      bestelling.email
  }
  is $ {
      bestelling.order
  }
</div>`
}

function saveOrder(bestelling) {
    orders.push(bestelling);
    localStorage.setItem('order', JSON.stringify(orders));

}