<div class="footer-rectangle"></div>
<p>designed by &#169; Patrick Poniatowski</p>
<div class="footer-socials">
    <a href="#"><img src="./img/facebook.png" class="social-icon" alt="facebook-icon"></a>
    <a href="#"><img src="./img/instagram.png" class="social-icon" alt="intagram-icon"></a>
</div>