<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <body id="page-top">
        <header>
            <?php echo $__env->make('partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>

        <div class="wrapper">
            <div id="social-countdown">
                <?php echo $__env->yieldContent('social'); ?>
            </div>

            <main id="line-up-link">
                <?php echo $__env->yieldContent('line-up'); ?>
            </main>

            <div id="ticket-link">
                <?php echo $__env->yieldContent('ticket'); ?>
            </div>

            <div class="container-gallery">
                <?php echo $__env->yieldContent('gallery'); ?>
            </div>

            <div id="partners-link">
                <?php echo $__env->yieldContent('partners'); ?>
            </div>

            <footer id="footer">
                <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </footer>
        </div>


    </body>
</body>

</html><?php /**PATH D:\OneDrive - Erasmushogeschool Brussel\School\2021-2022\trends II\trends-website\resources\views/layouts/master.blade.php ENDPATH**/ ?>