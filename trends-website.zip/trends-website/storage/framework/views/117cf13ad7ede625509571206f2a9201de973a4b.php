

<?php $__env->startSection('social-countdown'); ?>
<div class="fanpage-fb">
    <img src="./img/Screenshot 2022-03-26 192930.png" alt="fanpage-fb">
</div>
<div class="container-countdown">
    <h2>Volgende festival DaFest!</h2>
    <h3>13, 14, 15 Mei 2022,van Termunt Tervuren</h3>
    <div id="countdown">
        <ul>
            <li class="countdown-element"><span id="days"></span>
                <p>days</p>
            </li>
            <li class="countdown-element"><span id="hours"></span>
                <p>Hours</p>
            </li>
            <li class="countdown-element"><span id="minutes"></span>
                <p>Minutes</p>
            </li>
            <li class="countdown-element"><span id="seconds"></span>
                <p>Seconds</p>
            </li>
        </ul>
    </div>
    <footer>
        <a href="#"><button>Koop Nu tickets</button></a>
        <a href="#"><img src="./img/facebook.png" class="social-icon" alt="facebook-icon"></a>
        <a href="#"><img src="./img/instagram.png" class="social-icon" alt="intagram-icon"></a>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OneDrive - Erasmushogeschool Brussel\School\2021-2022\trends II\trends-website\resources\views/content/social-countdown.blade.php ENDPATH**/ ?>