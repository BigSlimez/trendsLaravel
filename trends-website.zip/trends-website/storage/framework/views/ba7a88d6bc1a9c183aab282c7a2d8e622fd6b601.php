<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('partials/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <body id="page-top">
        <header>
            <?php echo $__env->make('partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>

        <div class="wrapper">
            <div id="social-countdown">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </body>
</body>

</html><?php /**PATH D:\OneDrive - Erasmushogeschool Brussel\School\2021-2022\trends II\trends-website\resources\views/main.blade.php ENDPATH**/ ?>