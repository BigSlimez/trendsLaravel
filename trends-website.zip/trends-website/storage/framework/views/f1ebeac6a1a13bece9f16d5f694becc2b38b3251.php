

<?php $__env->startSection('line-up'); ?>
<div id="line-up">
    <div id='line-up-filter'>
        <button class='dag-een'>13 MEI</button>
        <button class='dag-twee'>14 MEI</button>
        <button class='dag-drie'>15 MEI</button>
    </div>

    <div id='posts'>
        <div class='post dag-een'>
            <figure>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">Yves Segers</p>
                    <p class="post-uur">18:00</p>
                </div>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">Feest Dj Lucki Luc</p>
                    <p class="post-uur">18:40</p>
                </div>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">2 Fabiola</p>
                    <p class="post-uur">19:30</p>
                </div>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">Sam Gooris</p>
                    <p class="post-uur">20:25</p>
                </div>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">Gebroeders Ko</p>
                    <p class="post-uur">21:00</p>
                </div>
                <div>
                    <img src="./img/7.png" alt="">
                    <p class="post-name">Ronny Retro</p>
                    <p class="post-uur">21:30</p>
                </div>
            </figure>
        </div>
        <div class='post dag-twee' style="display: none">
            <figure>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">Yves Segers</p>
                    <p class="post-uur">18:00</p>
                </div>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">Feest Dj Lucki Luc</p>
                    <p class="post-uur">18:40</p>
                </div>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">2 Fabiola</p>
                    <p class="post-uur">19:30</p>
                </div>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">Sam Gooris</p>
                    <p class="post-uur">20:25</p>
                </div>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">Gebroeders Ko</p>
                    <p class="post-uur">21:00</p>
                </div>
                <div>
                    <img src="./img/8.png" alt="">
                    <p class="post-name">Ronny Retro</p>
                    <p class="post-uur">21:30</p>
                </div>
            </figure>
        </div>
        <div class='post dag-drie' style="display: none">
            <figure>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">Yves Segers</p>
                    <p class="post-uur">18:00</p>
                </div>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">Feest Dj Lucki Luc</p>
                    <p class="post-uur">18:40</p>
                </div>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">2 Fabiola</p>
                    <p class="post-uur">19:30</p>
                </div>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">Sam Gooris</p>
                    <p class="post-uur">20:25</p>
                </div>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">Gebroeders Ko</p>
                    <p class="post-uur">21:00</p>
                </div>
                <div>
                    <img src="./img/10.png" alt="">
                    <p class="post-name">Ronny Retro</p>
                    <p class="post-uur">21:30</p>
                </div>
            </figure>
        </div>
    </div>
    <div class="h3-background">
        <h3>Line Up</h3>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OneDrive - Erasmushogeschool Brussel\School\2021-2022\trends II\trends-website\resources\views/content/line-up.blade.php ENDPATH**/ ?>